import time

for i in range(0,12):
    xy = (i+1)
    character = "am"
    print(xy,character)
    time.sleep(1)
for p in range(0,12):
    x = (p+1)
    character = "pm"
    print(x,character)
    time.sleep(1)